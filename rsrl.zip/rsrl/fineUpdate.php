<?php
$conn=mysqli_connect('localhost','id3093682_yashchandani98','110198');
if(isset($conn))
{
mysqli_select_db($conn,'id3093682_library');
echo"<form action='' method='post'>";
echo"RollNo.:<input type='number' name='roll'><br>";
echo"ReceiptNo.:<input type='text' name='receipt'><br>";
echo"<input type='submit' value='submit' name='sub'>";
echo"</form>";
if(isset($_POST['sub']))
{
    $today=date('d-m-y');
    $roll=$_POST['roll'];
    $receipt=$_POST['receipt'];
$q1="INSERT INTO Fine ('RollNo','Date','ReceiptNo') VALUES('$roll','$today','$receipt')";
mysqli_query($conn,$q1);
$q2="UPDATE user SET TotalFine='0' WHERE RollNo=$roll";
mysqli_query($conn,$q2);
}
}
?>