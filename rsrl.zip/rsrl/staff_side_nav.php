<html>
<style>
a{
text-decoration:none;
}
</style>
<body>
<ol style="list-style-type:none;">
<li style="color:green;font-size:30px;">Quick links</li>
<fieldset style="width:100px;">
<li style='font-size:30px;'><a href='return.php' target='down'>Return</a></li>
<br>
<li style='font-size:30px;'><a href='book_request.php' target='down'>Requests</a></li>
</fieldset>
</ol>
</body>
</html>