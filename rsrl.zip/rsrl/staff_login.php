<!DOCTYPE html>
<html>
<style>
form {
    border: 3px solid #f1f1f1;
}

input[type=text], input[type=password] {
    width: 50%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 50%;
}

.container {
    padding: 16px;
}

span.psw {
    float: center;
    padding-top: 16px;
}

@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
   
}
</style>
<body>

<h2>Staff Login Form</h2>

<form action="staff_login_data.php" method='post'>
  <div class="container">
    <label><b>UserId</b></label>
    <input type="text" placeholder="Enter UserId" name="sid" required>

    <br><label><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="spwd" required>
        
    <button type="submit">Login</button>
    <!--input type="checkbox" checked="checked"-->
  </div>
</form>

</body>
</html>
