<html>
<head>
<style>
body{
background-color:yellow;
}
form{
position:absolute;
left:300px;
top:30px;
}
</style>
</head>
<body>
<form action='books_new_data.php' enctype='multipart/form-data'method='post'>
BookId:<input type='text' name='bookId'>
<br>
BookName:<input type='text' name='bookName'>
<br>
Author:<input type='text' name='bookAuthor'>
<br>
Edition:<input type='text' name='bookEdition'>
<br>
Image:<input type='file' name='bookImg'>
<br>
RackNumber:<input type='number' name='rackNumber'>
<br>
<input type='submit' name='sub'>
</form>
</body>
</html>