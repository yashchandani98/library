<html>
<form action='uploadImage.php' enctype='multipart/form-data'method='post'>
<input type='file'name='img'>
<input type='submit' value='upload' name='submit'>
</form>
</html>