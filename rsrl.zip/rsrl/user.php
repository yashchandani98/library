<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<?php
echo"<div class='container-fluid'>";
$user=$_COOKIE['user'];
$roll=$_COOKIE['roll'];
//echo $roll;
$con=mysqli_connect('localhost','id3093682_yashchandani98','110198');
if(isset($con))
{
mysqli_select_db($con,'id3093682_library');
$q1="SELECT * FROM user WHERE RollNo='$roll'";
$result1=mysqli_query($con,$q1);
$arr1=mysqli_fetch_array($result1);
if($arr1['BookId1']!='0'or $arr1['BookId2']!='0')
{
echo"<div style='font-size:30px;color:green;'>You have:</div>";
}   
else{
echo"<p style='font-size:30px;'>You have no books now</p>";
}
if($arr1['Book1']!='0'and $arr1['BookId1']!='0')
{
$q2="SELECT * FROM books WHERE Id='$arr1[BookId1]'";
$result2=mysqli_query($con,$q2);
$arr2=mysqli_fetch_array($result2);
echo"<h1 style='text-size:30px;'>Book1:</h1>";
echo"<br>";
echo"<div class='row'>";
echo"<div class='col-sm-4'></div>";
echo"<div class='col-sm-4'>";
echo '<img src="data:image/jpeg;base64,'.base64_encode( $arr2['image'] ).'"/>'; 
echo"</div>";
echo"<div class='col-sm-4'>";
echo"<p style='font-size:30px;'>Id:".$arr2['Id'];
echo"<p style='font-size:30px;'>Name:".$arr2['Name'];
echo"<p style='font-size:30px;'>Issue Date:".$arr1['Book1IssueDate'];
echo"<p style='font-size:30px;'>Return Date:".$arr1['Book1ReturnDate'];
$today=date('d-m-y');
echo"<p style='font-size:30px;'>Today's Date:".$today;
$date1=date('y-m-d');
echo"<br>";
$return=$arr1['Book1ReturnDate'];
$return1=date_create($return);
$date3=date_format($return1,"d-m-y");
$date1=date_create($date1);
$date4=date_create($date3);
$diff=date_diff($date1,$date4);
$d=$diff->format("%a");
echo"<p style='font-size:30px;'>Days left:".$d;

//$td=date('y-m-d');
//$diff=date_diff($td,$today);
//$d=$diff->format("%R%a days");
//echo"<p style='font-size:30px;'>Days left:".$d;
if($today==$arr1['Book1ReturnDate'])
	echo"<p style='font-size:30px;'>Return your book today.</p>";
echo"</div>";
echo"</div>";
}
//----------------------------------------------------------------------------------------
if($arr1['Book2']!='0'and $arr1['BookId2']!='0')
{
$q2="SELECT * FROM books WHERE Id='$arr1[BookId2]'";
$result2=mysqli_query($con,$q2);
$arr2=mysqli_fetch_array($result2);
echo"<hr style='height:20px;'>";
echo"<h1 style='text-size:30px;'>Book2:</h1>";
echo"<br>";
echo"<div class='row'>";
echo"<div class='col-sm-4'></div>";
echo"<div class='col-sm-4'>";
echo '<img src="data:image/jpeg;base64,'.base64_encode( $arr2['image'] ).'"/>'; 
echo"</div>";
echo"<div class='col-sm-4'>";
echo"<p style='font-size:30px;'> Id:".$arr2['Id'];
echo"<p style='font-size:30px;'> Name:".$arr2['Name'];
echo"<p style='font-size:30px;'> Issue Date:".$arr1['Book2IssueDate'];
echo"<p style='font-size:30px;'> Return Date:".$arr1['Book2ReturnDate'];
echo"<p style='font-size:30px;'> Today's Date:".date('d-m-y');
$today=date('d-m-y');
//$td=date('y-m-d');
//$diff=date_diff($td,$today);
//$d=$diff->format("%R%a days");
//echo"<p style='font-size:30px;'>Days left:".$d;
if($today==$arr1['Book2ReturnDate'])
	echo"<p style='font-size:30px;'>Return your book today.</p>";
echo"</div>";
echo"</div>";
}

}
?>
</html>