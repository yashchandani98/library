<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Home Page</title>
<script>
function myFunction(x) {
    x.classList.toggle("change");
}
</script>
  <style>
  
 #search {
    width: 0px;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 700px;
    font-size: 16px;
    background-color: white;
    background-image: url('searchicon.png');
    background-position: 17px 6px; 
    background-repeat: no-repeat;
    padding: 12px 20px 12px 40px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
}
#search:hover{
width:100%;    
}
#search:focus{
width:100%;    
}

  .footer{
  position:absolute;
  left:0;
  bottom:0;
  background-color:black;
  }
  #title{
  position:absolute;
  left:20px;
  color:blue;
  }
  #but1 {
    background-color: #4CAF50;
    color: white;
    width:30px;
	height:30px;
    border: none;
    cursor: pointer;
    width: 50%;
}

  .affix {
      top: 0;
      width: 100%;
}
.affix + .container-fluid {
      padding-top: 70px;
  }
  #navbar{
  z-index:999;
  }
  #user{
  color:white;
  }  
  #bar1, #bar2, #bar3 {
    width: 35px;
    
    margin: 6px 0;
    transition: 0.5s;
}

.change #bar1 {
    -webkit-transform: rotate(-45deg) translate(-9px, 6px) ;
    transform: rotate(-45deg) translate(-5px, 8px) ;
}

.change #bar2 {opacity: 0;}

.change #bar3 {
    -webkit-transform: rotate(45deg) translate(-2px, -8px) ;
    transform: rotate(45deg) translate(-4px, -8px) ;
}
  </style>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container" style="background-color:white;color:#fff;height:100px; heigth:200px;">
<a href="#" style="text-decoration:none; font-size:40px; position:absolute; top:20px;
left:10px;"><img src='r2.jpg'width='80px' height='80px'> Library.mng</a>
</div>
<nav class="navbar navbar-inverse" id='navbar'style="background-color:green;" data-spy="affix" data-offset-top="197">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar" onclick="myFunction(this)">
        <span id='bar1' class="icon-bar"></span>
        <span id='bar2' class="icon-bar"></span>
        <span id='bar3' class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.php" title='Online LibraryManagement'>LibraryManagement</a>
   
    </div>
    <div class="collapse navbar-collapse" style="background-color:"id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.php"><span class="glyphicon glyphicon-home"></a></li>
        <form class="navbar-form navbar-right">
    <div class="input-group">
        <input type="text" class="form-control"id='search' placeholder="Search...">
        
      </div>
      </form>
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Books<span class="caret"></span></a>
          <ul class="dropdown-menu">
		    <li><a href='cse_books.php'>CSE</a></li>
            <!--li><a href="#">CSE 3rd sem</a></li>
            <li><a href="#">CSE 4th sem</a></li>
            <li><a href="#">CSE 5th sem</a></li>
			<li><a href="#">CSE 6th sem</a></li>
			<li><a href="#">CSE 7th sem</a></li>
			<li><a href="#">CSE 8th sem</a></li-->
			<!--li id="divider"></li-->
			<li><a href='#'>MECH</a></li>
			<!--li><a href="#">MECH 3rd sem</a></li>
            <li><a href="#">MECH 4th sem</a></li>
            <li><a href="#">MECH 5th sem</a></li>
			<li><a href="#">MECH 6th sem</a></li>
			<li><a href="#">MECH 7th sem</a></li>
			<li><a href="#">MECH 8th sem</a></li-->
            <li><a href='#'>Civil</a></li>
			<li><a href='#'>EEE</a></li>
			<li><a href='#'>ET&T</a></li>
		  </ul>
        </li>
        <?php
            $conn=mysqli_connect('localhost','id3093682_yashchandani98','110198');
            if(isset($conn))
            {
                mysqli_select_db($conn,'id3093682_library');
                $rol=$_COOKIE['roll'];
               // echo$rol;
            $q1="SELECT * FROM user WHERE RollNo=$rol";
            $result=mysqli_query($conn,$q1);
            $row=mysqli_fetch_array($result);
            $fine=$row['Totalfine'];
            //echo"<script>alert('Your Due in RS.$row[TotalFine]');</script>";
            
            //echo"";
            }
            ?>
            <li onclick='alert(<?php echo $fine;?>)'><a href>My Library Due</a></li>
        <!--li onclick="alert(<?Php echo $fine;?>)"><a>lb</a></li-->
        
                
            
        
		<!--li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">Languages<span class="caret"></span></a>
		  <ul class="dropdown-menu">
		  <li><a href="#">C</a></li>
		  <li><a href="#">C++</a></li>
		  </ul>
		  </li-->
        <!--form class="navbar-form navbar-left">
      <div class="form-group">
        <input type="text" class="form-control" placeholder="Search">
      </div>
      <button type="submit" class="btn btn-default">Submit</button>
    </form-->
      <!--?php
	  
		  echo"<li><button class='btn'>Account settings</button></li>";
	  ?-->
	  </ul>
	  <?php
	  $conn=mysqli_connect('localhost','id3093682_yashchandani98','110198');
	  mysqli_select_db($conn,'id3093682_library');
	  $q1="SELECT image FROM signup";
	  $result=mysqli_query($conn,$q1);
	  $arr=mysqli_fetch_array($result);
	  //session_start();
	  if(isset($_SESSION['USER']))
	  {
	  echo"<ul class='nav navbar-nav navbar-right'>";
	  echo"<li><a href='logout.php'>Logout  <span class='glyphicon glyphicon-log-out'></span></a></li>";
	  echo"<li class='active'id='user'>Hello ".$_COOKIE['user']."</li>";
      echo"<li><img src='$_COOKIE[img]'alt='UserImg'class='img-circle' width='50' height='50'></li>";

	  echo"</ul>";
	  }
	  else{
       echo"<script>location='index.php';</script>";
	 
	  //<!--button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button>

  //<!-- Modal -->
    
    //  <!-- Modal content-->
echo"<div class='modal fade' id='signup' role='dialog'>";
echo"<div class='modal-dialog'>";
echo"<div class='modal-content'>";
echo"<div class='modal-header'>";
echo"<button type='button' class='close' data-dismiss='modal'>&times;</button>";
echo"<h4 class='modal-title'>Modal Header</h4>";
echo"</div>";
echo"<form action='signup_data.php'enctype='multipart/form-data' id='f1' method='post'>";
echo"<div id='b2'>Create account</div><br><br><br>";
echo"Your name:<br><br>";
echo"<input type='text' placeholder='Enter your name..' name='name' required>
<br><br>
Image:<input type='file' name='img' required>
<br><br>
Mobile number:
<br><br>+91
<input type='number' placeholder='Mobile number..' name='mob_no' required>
<br><br>
Roll-no:<br><br>
<input type='number' placeholder='Roll no..' name='roll' size='30' required>
<br><br>
Branch:
<select name='branch'>
<option value='Computer Science'id='cs'>Computer Science</option>
<option value='Civil' id='ci'>Civil</option>
<option value='Mechanical' id='mech'>Mechanical</option>
<option value='Electrical' id='eee'>Electrical</option>
</select>
<br><br>
Course:
<select name='course'>
<option value='BE'>BE</option>
<option value='Diploma'>Diploma</option>
</select>
<br><br>
Password:<br><br>
<input type='password' placeholder='Atleast 8 characters...' name='pwd' required>
<br><br>
Re-enter Password:<br><br>
<input type='password' placeholder='Password shold be match...' name='pwd2' required>
<br><br>
<input type='submit' name='sub' value='Create' id='but1'>
<br>
<input type='checkbox' name='check' onclick='fun1()'>I agree to the terms and conditions.
<br><br><br>
Already have an account?<a href='login.php'>Sign in</a>
</form>";
echo"<button type='button' class=btn btn-default' data-dismiss='modal'>Close</button>";
echo"</div>";
echo"</div>";
echo"</div>";
 echo"</div>";
//----------------------------------------------
echo"<div class='container'>";
echo"<div class='modal fade' id='login' role='dialog'>";
echo"<div class='modal-dialog'>";
echo"<div class='modal-content'>";
echo"<div class='modal-header'>";
echo"<button type='button' class='close' data-dismiss='modal'>&times;</button>";
echo"<h4 class='modal-title'>Login to your account</h4>";
echo"</div>";
echo"<form action='login_data.php'method='post'id='b1'>";
echo"Rollno:<input type='number' name='roll'placeholder='Enter Rollno' required>";
echo"<br>";
echo"Password:<input type='password'name='pwd'placeholder='Enter Password' required>";
echo"<br>";
echo"<input type='submit' name='sub' id='but1'>";
echo"<br>";
echo"Not have an account?";
echo"<a href='signup.php' target='_blank'>Create an account</a>";
echo"</form>";
echo"<div class='modal-footer'>";
echo"<button type='button' class=btn btn-default' data-dismiss='modal'>Close</button>";
echo"</div>";
echo"<div>";
echo"</div>";
echo"</div>";
 echo"</div>";
  
	  }
	  ?>
    </div>
    

  </div>
</nav>
<?php
if(isset($_SESSION['USER']))
{
    echo"<div class='container-fluid'>";
$user=$_COOKIE['user'];
$roll=$_COOKIE['roll'];
//echo $roll;
$con=mysqli_connect('localhost','id3093682_yashchandani98','110198');
if(isset($con))
{
mysqli_select_db($con,'id3093682_library');
$q1="SELECT * FROM user WHERE RollNo='$roll'";
$result1=mysqli_query($con,$q1);
$arr1=mysqli_fetch_array($result1);
if($arr1['BookId1']!='0'or $arr1['BookId2']!='0')
{
echo"<div style='font-size:30px;color:green;'>You have:</div>";
}   
else{
echo"<p style='font-size:30px;'>You have no books now</p>";
}
if($arr1['Book1']!='0'and $arr1['BookId1']!='0')
{
$q2="SELECT * FROM books WHERE Id='$arr1[BookId1]'";
$result2=mysqli_query($con,$q2);
$arr2=mysqli_fetch_array($result2);
echo"<h1 style='text-size:30px;'>Book1:</h1>";
echo"<br>";
echo"<div class='row'>";
echo"<div class='col-sm-4'></div>";
echo"<div class='col-sm-4'>";
echo '<img src="data:image/jpeg;base64,'.base64_encode( $arr2['image'] ).'"/>'; 
echo"</div>";
echo"<div class='col-sm-4'>";
echo"<p style='font-size:30px;'>Id:".$arr2['Id'];
echo"<p style='font-size:30px;'>Name:".$arr2['Name'];
echo"<p style='font-size:30px;'>Issue Date:".$arr1['Book1IssueDate'];
echo"<p style='font-size:30px;'>Return Date:".$arr1['Book1ReturnDate'];
$today=date('d-m-y');
echo"<p style='font-size:30px;'>Today's Date:".$today;
$date1=date('y-m-d');
echo"<br>";
$return=$arr1['Book1ReturnDate'];
$return1=date_create($return);
$date3=date_format($return1,"d-m-y");
$date1=date_create($date1);
$date4=date_create($date3);
$diff=date_diff($date1,$date4);
$d=$diff->format("%a");
/*if($today>$return){
echo"<p style='font-size:30px;'>Days gone for submission:".$d;
echo"<p style='font-size:30px;'>Hurry up! Go and return your book";
}
else*/
echo"<p style='font-size:30px;'>Days left:".$d;

//$td=date('y-m-d');
//$diff=date_diff($td,$today);
//$d=$diff->format("%R%a days");
//echo"<p style='font-size:30px;'>Days left:".$d;
if($today==$arr1['Book1ReturnDate'])
	echo"<p style='font-size:30px;'>Return your book today.</p>";
echo"</div>";
echo"</div>";
}
//----------------------------------------------------------------------------------------
if($arr1['Book2']!='0'and $arr1['BookId2']!='0')
{
$q2="SELECT * FROM books WHERE Id='$arr1[BookId2]'";
$result2=mysqli_query($con,$q2);
$arr2=mysqli_fetch_array($result2);
echo"<hr style='height:20px;'>";
echo"<h1 style='text-size:30px;'>Book2:</h1>";
echo"<br>";
echo"<div class='row'>";
echo"<div class='col-sm-4'></div>";
echo"<div class='col-sm-4'>";
echo '<img src="data:image/jpeg;base64,'.base64_encode( $arr2['image'] ).'"/>'; 
echo"</div>";
echo"<div class='col-sm-4'>";
echo"<p style='font-size:30px;'> Id:".$arr2['Id'];
echo"<p style='font-size:30px;'> Name:".$arr2['Name'];
echo"<p style='font-size:30px;'> Issue Date:".$arr1['Book2IssueDate'];
echo"<p style='font-size:30px;'> Return Date:".$arr1['Book2ReturnDate'];
echo"<p style='font-size:30px;'> Today's Date:".date('d-m-y');
$today=date('d-m-y');
//$td=date('y-m-d');
//$diff=date_diff($td,$today);
//$d=$diff->format("%R%a days");
//echo"<p style='font-size:30px;'>Days left:".$d;
$date1=date('y-m-d');
echo"<br>";
$return=$arr1['Book2ReturnDate'];
$ret=strtotime($return);
$return1=date_create($return);
$date3=date_format($return1,"d-m-y");
$td=strtotime($date3);
//echo$td;
$date1=date_create($date1);
$date4=date_create($date3);
$diff=date_diff($date1,$date4);
$d=$diff->format("%a");
/*if($td>$ret){
echo"<p style='font-size:30px;'>Days gone for submission:".$d;
echo"<p style='font-size:30px;'>Hurry up! Go and return your book";
}
else*/
echo"<p style='font-size:30px;'>Days left:".$d;


if($today==$arr1['Book2ReturnDate'])
	echo"<p style='font-size:30px;'>Return your book today.</p>";
echo"</div>";
echo"</div>";
}

}
}

//include'Footer-with-button-logo - Copy.html';

?>
<!--div class="jumbotron">
<blockquote>Yash chandani</blockquote>
</div-->
<!--div class="container-fluid" style="height:1000px">
  <h1>Pull down to see the effect</h1>
  <h1>Pull down to see the effect</h1>
  <h1>Pull down to see the effect</h1>
  <h1>Pull down to see the effect</h1>
  <h1>Pull down to see the effect</h1>
  <h1>Pull down to see the effect</h1>
  <h1>Pull down to see the effect</h1>
  <h1>Pull down to see the effect</h1>
  <h1>Pull down to see the effect</h1>
  <h1>Pull down to see the effect</h1>
  <h1>Pull down to see the effect</h1>
  <h1>Pull down to see the effect</h1>
  
<!--button class='btn'>Click me</button><script>
$(document).ready(function(){
    $('.btn').popover({title: "<h1><strong>HTML</strong>echo $_COOKIE['user']; inside <code>the</code> <em>popover</em></h1>", content: "<a href='#'>click me</a><br> <h2>Cool stuff!</h2>", html: true,php: true, placement: "right"}); 
});
</script-->
<!--/div>
<footer>
HELL
</footer-->
<!--div id='title'><i>NewComers</i></div> 

<?php
$servername = "localhost";
$username = "id3093682_yashchandani98";
$password = "110198";
$dbname = "id3093682_library";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM books";
$res = mysqli_query($conn,$sql);
/*echo "<table class = 'table'>";
echo"<tr>";
echo"<th>"; echo"Book ID"; echo"</th>";
echo"<th>"; echo"Book Author"; echo"</th>";
echo"<th>"; echo"Book Name"; echo"</th>";
echo"<th>"; echo"Edition"; echo"</th>";
echo"<th>"; echo"Image"; echo"</th>";
echo"<th>"; echo"RackNumber"; echo"</th>";
echo"<th>"; echo"Created"; echo"</th>";
echo"</tr>";*/
while($row = mysqli_fetch_array($res))
{
//echo"<tr>";
//echo"<td>"; 
echo"<div class='thumbnail'>";
echo '<img src="data:image/jpeg;base64,'.base64_encode( $row['image'] ).'"/>'; echo"</td>";
echo"<div class='caption'><p style='font-size:30px;'>Name:".$row['Name']."<br>Author:".$row['Author']."<br>Edition:".$row['Edition']."</p></div>";
echo"</div>";
//echo"<td>"; 
//echo $row["Id"]; 
//echo"</td>";
//echo"<td>"; echo $row["Author"]; echo"</td>";
//echo"<td>"; echo $row["Name"]; echo"</td>";
//echo"<td>"; echo $row["Edition"]; echo"</td>";
//echo"<td>"; echo $row["RackNumber"]; echo"</td>"; 
//echo"<td>"; echo $row["created"]; echo"</td>";
//echo"</tr>";


//echo"</table>";
//mysqli_close($conn);
//<div class='thumbnail'>
//<img src='' class='img-responsive'>
//</div>
}
?>
<div class='footer'>
<span class='glyphicon glyphicon-facebook'>
</div-->
</body>
</html>
     