<?php
session_start();
?>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
#staff_name{
position:absolute;
left:1100px;
color:blue;
}
#logout{
position:absolute;
left:1200px;
color:blue;
}
a{
text-decoration:none;
}
#title{
position:absolute;
left:250px;
top:20px;
font-size:50px;
border:2px;
}
#img1{
position:absolute;
top:20px;
left:100px;
height:60%;
}
table{
position:absolute;
left:100px;
top:130px;
}
</style>
</head>
<?php
if(isset($_SESSION['staff']))
{
echo"<img src='library.jpg' id='img1'>";
echo"<div id='title'><i>Library supervision</i></div>";
echo"<div id='staff_name'>".$_COOKIE['staff']."</div>";
echo"<span class='glyphicon glyphicon-log-out' id='logout'><a href='staff_logout.php' target='_parent'>Logout</a></span>";
echo"<table>";
echo"<tr>";
echo"<th><a href=''target='down'>Total Books in stock</a></th>";
echo"<th>||</th>";
//echo"<th>||</th>";
echo"<th><a href='#' target='down'>Issued Books</a></th>";
//echo"<th></a></th>";
echo"<th>||</th>";
echo"<th><a href='books_new.php' target='down'>Add Books to new stock</a></th>";
echo"<th>||</th>";
echo"<th><a href='bookTitleInsert.php' target='down'>Add New Book Title</a></th>";
echo"<th>||</th>";
echo"<th><a href='fineUpdate.php' target='down'>Update Fine</a></th>";
echo"<th>||</th>";
echo"<th><a href='fineSee.php' target='down'>See Fine</a></th>";
echo"</tr>";
echo"</'table>";
}
?>
</html>