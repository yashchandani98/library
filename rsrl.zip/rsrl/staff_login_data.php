<?php
$sid=$_POST['sid'];
$spwd=$_POST['spwd'];
$con=mysqli_connect('localhost','id3093682_yashchandani98','110198');
if(isset($con))
{
mysqli_select_db($con,'id3093682_library');
$q1="SELECT * FROM staff";
$result=mysqli_query($con,$q1);
$rows=mysqli_num_rows($result);
$find=0;
for($i=0;$i<$rows;$i++)
{
$arr=mysqli_fetch_array($result);
if($sid==$arr['UserId'])
{$find=1;
if($spwd==$arr['Password'])
{
session_start();
$_SESSION['staff']=1;
setcookie('staff',$arr['Name']);
echo"<script>location='staff_work.php';</script>";
}
else{
echo"<script>alert('Invalid password');location='staff_login.php';</script>";
}
}
}
if($find==0)
	{
echo"<script>alert('Staff doesn't exist make sure you have entered correct ID');location='staff_login.php';</script>";
}
}
?>