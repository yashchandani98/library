<?php
$con=mysqli_connect('localhost','id3093682_yashchandani98','110198');
if(isset($con))
{
mysqli_select_db($con,'id3093682_library');
$roll=$_REQUEST['roll'];
$book=$_REQUEST['book'];
$id=$_REQUEST['id'];
$q1="SELECT * FROM user WHERE RollNo=$roll";
$result=mysqli_query($con,$q1);
$arr=mysqli_fetch_array($result);
if($arr['Book1']=='0' and $arr['BookId1']=='0')
{
	$date=date("d-m-y");
	$return=date("d-m-y", strtotime("+14 days"));
	$q2="UPDATE user SET Book1='$book',BookId1='$id',Book1IssueDate='$date',Book1ReturnDate='$return' WHERE RollNo=$roll";
//$q3="UPDATE `user` SET `RollNo`=$roll,`Name`='Yash chandani',`Book1`=$book,`Book2`=null,`BookId1`=$id,`BookId2`=null";
//$result=mysqli_query($con,$q2);
if($con->query($q2))
{
$q3="UPDATE books SET Issued='1' WHERE Id='$id'";
if($con->query($q3))
{
$que="DELETE FROM bookrequest WHERE BookId='$id'";
if($con->query($que))
	echo"<script>location='book_request.php';</script>";

else
	echo$con->error;
}
else{
echo$con->error;
}
}
else{
echo$con->error;
}
}
else
{
if($arr['Book2']=='0' and $arr['BookId2']=='0')
{
	$date=date("d-m-y");
	$return=date("d-m-y", strtotime("+14 days"));
	$q4="UPDATE user SET Book2='$book',BookId2='$id',Book2IssueDate='$date',Book2ReturnDate='$return' WHERE RollNo=$roll";
if($con->query($q4))
{
$que="DELETE FROM bookrequest WHERE BookId='$id'";
if($con->query($que))
	echo"<script>location='book_request.php';</script>";

}
}
else{
echo"User have issued 2 books which is limited tell him to return any 1 book and try again";
$que="DELETE FROM BookRequest WHERE RollNo=$roll";
mysqli_query($con,$que);
}
}
}
?>