<?Php
$con=mysqli_connect('localhost','id3093682_yashchandani98','110198');
if(isset($con))
{
mysqli_select_db($con,'id3093682_library');
$id=$_POST['bookId'];
$nm=$_POST['bookName'];
$ath=$_POST['bookAuthor'];
$ed=$_POST['bookEdition'];
$rn=$_POST['rackNumber'];
$dataTime = date("d-m-y H:i:s");
//$check = getimagesize($_FILES["image"]["tmp_name"]);
$image = $_FILES['bookImg']['tmp_name'];
$imgContent = addslashes(file_get_contents($image));
$dataTime = date("d-m-y");
$insert = $con->query("INSERT into books (Id,Author,Name,Edition,Image,RackNumber,Date) VALUES ('$id','$ath','$nm','$ed','$imgContent','$rn','$dataTime')");
if($insert)
	echo"Record inserted successfully";
        
}
?>
<!--?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "library";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM images";
$res = mysqli_query($conn,$sql);
echo "<table class = 'table'>";
echo"<tr>";
echo"<th>"; echo"Book ID"; echo"</th>";
echo"<th>"; echo"Book Author"; echo"</th>";
echo"<th>"; echo"Book Name"; echo"</th>";
echo"<th>"; echo"Edition"; echo"</th>";
echo"<th>"; echo"Image"; echo"</th>";
echo"<th>"; echo"RackNumber"; echo"</th>";
echo"<th>"; echo"Created"; echo"</th>";
echo"</tr>";
while($row = mysqli_fetch_array($res))
{
echo"<tr>";
echo"<td>"; echo $row["Id"]; echo"</td>";
echo"<td>"; echo $row["Author"]; echo"</td>";
echo"<td>"; echo $row["Name"]; echo"</td>";
echo"<td>"; echo $row["Edition"]; echo"</td>";
echo"<td>"; echo '<img src="data:image/jpeg;base64,'.base64_encode( $row['image'] ).'" width="200%"/>'; echo"</td>";
echo"<td>"; echo $row["RackNumber"]; echo"</td>"; 
echo"<td>"; echo $row["created"]; echo"</td>";
echo"</tr>";

}
echo"</table>";
mysqli_close($conn);
?-->
