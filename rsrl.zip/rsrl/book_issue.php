<?php
session_start();
if(isset($_SESSION['USER']))
{
setcookie('book',$_REQUEST['name']);
$con=mysqli_connect('localhost','id3093682_yashchandani98','110198');
if(isset($con))
{
mysqli_select_db($con,'id3093682_library');
	//$q1="SELECT * FROM `books` WHERE Name='Object oriented programming with c++' AND Issued='0'";
	$q1="SELECT * FROM books WHERE Name='$_REQUEST[name]' AND Issued='0'";
	$result=mysqli_query($con,$q1);
	$row=mysqli_fetch_array($result);
	if(isset($row))
	{
	echo"<div class='container'>";
    echo '<img src="data:image/jpeg;base64,'.base64_encode( $row['image'] ).'"/>'; echo"</td>";
    echo$row['Name'];
	echo"<br>";
	echo$row['Id'];
	echo"<br>";
	echo"<a href='request.php?name=$row[Name]&id=$row[Id]&rack=$row[RackNumber]'>Confirm</a>";
    echo"</div>";
}
else{
echo"Books is not in stock Wait for some days.";
}
}
}
else{
echo"<script>alert('First login to your account');location='index.php';</script>";
}
?>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
