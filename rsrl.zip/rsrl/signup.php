<style>
#f1
{
position:absolute;
left:500px;
top:100px;
background-color: lightgrey;
width: 300px;
border: 25px; /*solid green;*/
padding: 25px;
margin: 25px;
}
#b2{
font-size:35px;
}
#but1
{
background-color:green;
height:30px;
/*display:none;*/
width:300px;
}
#t1{
position:relative;
left:550px;
top:10px;
font-size:50px;
color:black;
}
#t2{
position:relative;
left:550px;
top:10px;
font-size:30px;
}
a{
text-decoration:none;
}
</style>
</head>
<form action="signup_data.php" enctype="multipart/form-data" id="f1" method="post">
<div id="b2">Create account</div><br><br><br>
Your name:<br><br>
<input type="text" placeholder="Enter your name.." name="name" required>
<br><br>
Image:<input type="file" name='img' required>
<br><br>
Mobile number:
<br><br>+91
<input type="number" placeholder="Mobile number.." name="mob_no" required>
<br><br>
Roll-no:<br><br>
<input type="number" placeholder="Roll no.." name="roll" size="30" required>
<br><br>
Branch:
<select name="branch">
<option value="Computer Science"id="cs">Computer Science</option>
<option value="Civil" id="ci">Civil</option>
<option value="Mechanical" id="mech">Mechanical</option>
<option value="Electrical" id="eee">Electrical</option>
</select>
<br><br>
Course:
<select name="course">
<option value="BE">BE</option>
<option value="Diploma">Diploma</option>
</select>
<br><br>
Password:<br><br>
<input type="password" id='pwd1'placeholder="Atleast 8 characters..." name="pwd" required>
<br><input type='checkbox' onclick='passFunction1()'>Show me
<br><br>
Re-enter Password:<br><br>
<input type="password" id='pwd2'placeholder="Password shold be match..." name="pwd2" required>
<br><input type='checkbox' onclick='passFunction2()'>Show me
<script>
function passFunction1() {
    var x = document.getElementById("pwd1");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}

function passFunction2() {
    var x = document.getElementById("pwd2");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}
</script>
<br><br>
<input type="submit" name="sub" value="Create" id="but1">
<br>
<input type="checkbox" name="check" onclick="fun1()">I agree to the terms and conditions.
<br><br><br>
Already have an account?<a href="login.php">Sign in</a>
</form>
</html>