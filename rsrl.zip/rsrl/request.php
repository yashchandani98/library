<?php
date_default_timezone_set('Asia/Kolkata');
$roll=$_COOKIE['roll'];
$book=$_REQUEST['name'];
$id=$_REQUEST['id'];
$rack=$_REQUEST['rack'];
$name=$_COOKIE['user'];
$con=mysqli_connect('localhost','id3093682_yashchandani98','110198');
if(isset($con))
{
mysqli_select_db($con,'id3093682_library');
$qu="SELECT * FROM user WHERE RollNo='$roll'";
$result=mysqli_query($con,$qu);
$row=mysqli_fetch_array($result);
if($row['Book1']=='0'or$row['Book2']=='0')
	{$date=date("d-m-y");
//$que="SELECT * FROM "
$q1="INSERT INTO bookrequest (RollNo,Name,BookName,BookId,Rack,Date) VALUES('$roll','$name','$book','$id','$rack','$date')";
mysqli_query($con,$q1);
$q2="UPDATE books SET Issued='1' WHERE Id='$id'";
mysqli_query($con,$q2);
echo "<p style='font-size:30px;'>Please go to library and take book today otherwise your request will be deleted.</p>";
echo"<a href='index3.php' style='font-size:30px;'>Go to Main page</a>";
}
else{
echo"<p style='font-size:30px;'>You have Issued both books please return any one and try again.</p>";
}
}
?>