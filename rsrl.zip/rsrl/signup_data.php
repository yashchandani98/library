<?php
$con=mysqli_connect('localhost','id3093682_yashchandani98','110198');
if(isset($_POST['check']))
{
if($_POST['pwd']==$_POST['pwd2'])
{
if(isset($con))
{
mysqli_select_db($con,'id3093682_library');
//$y="DELETE FROM Signup";
//$con->query($y);
$roll1=$_POST['roll'];
//-----------------------------------------------//
$imagename = $_FILES['img']['name'];  // storing file name
	 $tempimgname =$_FILES['img']['tmp_name']; // temp name store
	 $con = mysqli_connect('localhost','id3093682_yashchandani98','110198') or die(mysqli_error());
	 mysqli_select_db($con,'id3093682_library');
      $image =move_uploaded_file($tempimgname,"$imagename");
	 $q = "INSERT INTO image(RollNo, Name,Image) VALUES ('$roll1','$imagename','$image')";
	 $result = mysqli_query($con,$q);
if(! $result)
{
die('INvalid query:' . mysqli_error());
}
//-----------------------------------------------//
$name=$_POST['name'];
$mob=$_POST['mob_no'];
$roll=$_POST['roll'];
$pwd=$_POST['pwd'];
//$branch= explode("_",$_POST['branch']);
$branch=$_POST['branch'];
$course=$_POST['course'];
$q2="SELECT RollNo FROM signup";
$q21=mysqli_query($con,$q2);
$r=mysqli_num_rows($q21);
for($i=0;$i<$r;$i++)
{
$row=mysqli_fetch_array($q21);
if($row['RollNo']==$roll)
{
echo"<script>alert('User exist with this Roll number Please Login');location='index3.php';</script>";
}
}
$image = $_FILES['img']['tmp_name'];
//$imgContent = addslashes(file_get_contents($image));
//$imgContent = addslashes(file_get_contents($image));
/*echo $name.$mob.$roll.$pwd;*/
$q1="INSERT INTO signup (Name,MobileNumber,RollNo,Password,Branch,Course,image) VALUES ('$name','$mob','$roll','$pwd','$branch','$course','$imagename')";
mysqli_query($con,$q1);
$q3="INSERT INTO user(RollNo,Name,Book1,Book2,BookId1,BookId2,Book1IssueDate,Book1ReturnDate,Book2IssueDate,Book2ReturnDate) values('$roll','$name','0','0','0','0','0-0-0','0-0-0','0-0-0','0-0-0')";
mysqli_query($con,$q3);
//echo"Hello";
//else
//echo "NOT";
//if ($con->query($q1) === TRUE) {
  //  echo "New record created successfully";
//} else {
  //  echo "Error: " . $q1 . "<br>" . $con->error;
//}

/*$q2="select * from Signup";
$result=mysqli_query($con,$q2);
$num=mysqli_num_rows($result);
for($i=0;$i<$num;$i++)
{
$row=mysqli_fetch_array($result);
echo $row['Name']."||".$row['MobileNumber']."||".$row['RollNo']."||".$row['Password'];
echo"<br>";
}*/
echo"<script>alert('After signup you have to login first');location='index3.php';</script>";
mysqli_close($con);
}
}
else
{
echo"<script>alert('Password mismatch');location='signup.php';</script>";
}
}
else
{
echo"<script>alert('Please accept Terms and conditions');location='signup.php';</script>";
}
?>