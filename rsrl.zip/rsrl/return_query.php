<?Php
$con=mysqli_connect('localhost','id3093682_yashchandani98','110198');
if(isset($con))
{
$id=$_GET['bookId'];
mysqli_select_db($con,'id3093682_library');
$q1="SELECT * FROM user WHERE BookId1='$id'";
$result=mysqli_query($con,$q1);
$row=mysqli_fetch_array($result);
if($row['BookId1']==$id)
{
$q3="UPDATE user SET Book1='0',BookId1='0',Book1IssueDate='0-0-0',Book1ReturnDate='0-0-0'  WHERE BookId1='$id'";
mysqli_query($con,$q3);
$q4="UPDATE books SET Issued='0' WHERE Id='$id'";
mysqli_query($con,$q4);
$q6="SELECT RackNumber FROM books WHERE Id='$id'";
$result=mysqli_query($con,$q6);
$arr=mysqli_fetch_array($result);
echo"<h1>Please keep this book in RackNumber:".$arr['RackNumber']."</h1>";
echo"<p style='font-size:25px;'>RollNo,:".$row['RollNo']."<br>Issue Date:",$row['Book1IssueDate']."<br>Return Date:".$row['Book1ReturnDate']."<br>Today's Date:".date('d-m-y')."</p>";
echo"<form action='fine.php?roll=$row[RollNo]' method='post'>";
echo"Fine:<input type='number' name='fine'>";
echo"<input type='submit' value='Submit'>";
echo"</form>";
    
}
else
{
$q2="SELECT * FROM user WHERE BookId2='$id'";
$res=mysqli_query($con,$q2);
$row=mysqli_fetch_array($res);
$query="SELECT * FROM user";

$q3="UPDATE user SET Book2='0',BookId2='0',Book2IssueDate='0-0-0',Book2ReturnDate='0-0-0'  WHERE BookId2='$id'";
mysqli_query($con,$q3);
$q5="UPDATE books SET Issued='0' WHERE Id='$id'";
mysqli_query($con,$q5);
$q6="SELECT RackNumber FROM books WHERE Id='$id'";
$result=mysqli_query($con,$q6);
$arr=mysqli_fetch_array($result);
echo"<h1>Please keep this book in RackNumber:".$arr['RackNumber']."</h1>";
echo"<p style='font-size:25px;'>RollNo,:".$row['RollNo']."<br>Issue Date:",$row['Book2IssueDate']."<br>Return Date:".$row['Book2ReturnDate']."<br>Today's Date:".date('d-m-y')."</p>";
echo"<form action='fine.php?roll=$row[RollNo]' method='post'>";
echo"Fine:<input type='number' name='fine'>";
echo"<input type='submit' value='Submit'>";
echo"</form>";
    }
}
?>