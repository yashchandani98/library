<html>
<body>
<?php
session_start();
mysql_connect('localhost','id3093682_yashchandani98','110198');
mysql_select_db('id3093682_library');
$q="select * from images ";
echo"<table border=2>
  <tr><td>g_name</td><td>Name</td><td>mob</td><td>Image</td></tr>";
$rs=mysql_query($q);
while($row=mysql_fetch_array($rs))
{
echo"<tr><td value=$row[g_name]>$row[g_name]<td value=$row[Name]>$row[Name]</td><td value=$row[mob]>$row[mob]</td>
<td> <img src='$row[image]' height='150px' width='150px'>$row[image]</td></tr>";
}
  echo"</table>";
  echo"<a href='home.php'>home</a>";
  ?>
 

</body>
</html>