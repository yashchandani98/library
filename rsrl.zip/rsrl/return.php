<html>
<style>
form{
position:absolute;
left:300px;
top:200px;
}
#subBut{
width:200px;
background-color:green;
}
</style>
<form action='return_query.php' action='get'>
BookId:<input type='text' name='bookId' placeholder='Enter Book id...'> 
<br>
<input type='submit' name='sub' id='subBut'>
</form>
</html>