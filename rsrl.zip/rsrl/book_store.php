<?php
$con=mysqli_connect('localhost','id3093682_yashchandani98','110198');
if(isset($con))
{
mysqli_select_db($con,'id3093682_library');
$q1="INSERT INTO books (Id,Author,Subject,Name,Edition) VALUES ('cse01','EBalaguruSwamy','Java','Programming in java',3)";
mysqli_query($con,$q1);
}
?>