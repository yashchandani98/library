<?php
$conn=mysqli_connect('localhost','id3093682_yashchandani98','110198');
if(isset($conn))
{
mysqli_select_db($conn,'id3093682_library');
echo"<form action='' method='post'>";
echo"RollNo.<input type='number' name='roll'>";
echo"<input type='submit' value='submit' name='sub'>";
echo"</form>";
if(isset($_POST['sub']))
{
$q1="SELECT TotalFine FROM user WHERE RollNo='$_POST[roll]'";
$result=mysqli_query($conn,$q1);
$row=mysqli_fetch_array($result);
echo"<h1>Fine:".$row['TotalFine']."</h1>";
}
}
?>