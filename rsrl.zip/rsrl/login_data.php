<?php
session_start();
$con=mysqli_connect('localhost','id3093682_yashchandani98','110198');
if(isset($con))
{
//if(isset($_POST['but1']))
//{
mysqli_select_db($con,'id3093682_library');
$roll=$_POST['roll'];
$pwd=$_POST['pwd'];
//echo$roll;
$q1="SELECT * FROM signup";
$result=mysqli_query($con,$q1);
$row=mysqli_num_rows($result);
$f=0;
for($i=0;$i<$row;$i++)
{
$arr=mysqli_fetch_array($result);
if($roll==$arr['RollNo'])
{
$f=1;
if($pwd==$arr['Password'])
{
$_SESSION['USER']=$arr['Name'];
setcookie('user',$arr['Name']);
$q1="select * FROM signup WHERE RollNo='$roll'";
$result=mysqli_query($con,$q1);
$row=mysqli_fetch_array($result);
setcookie('img',$row['image']);
setcookie('roll',$roll);
echo"<script>location='index.php';</script>";
}
else
{
echo"<script>alert('Invalid passowrd');location='index.php';</script>";
}
}
//else
//{
//echo"<script>alert('User not exist please create an account');location='index3.php';</script>";
//}
}
if($f==0)
echo"<script>alert('User not exist please create an account');location='index3.php';</script>";

//}
/*else
{
echo"WTF";
}*/
}



?>
<html>
<style>
a{
text-decoration:none;
}
</style>
</html>
<?php

?>