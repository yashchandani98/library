<?Php
session_start();
session_destroy();
unset($_COOKIE['img']);
echo"<script>location='index.php';</script>";
?>