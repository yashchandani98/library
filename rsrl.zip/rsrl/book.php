<html>
<head>
</head>
<body>
<?php
$con=mysqli_connect('localhost','id3093682_yashchandani98','110198');
if(isset($con))
{
mysqli_select_db($con,'id3093682_library');
$q1="SELECT * FROM books";
$result=mysqli_query($con,$q1);
$row=mysqli_num_rows($result);
echo"<table>";
echo"<tr>";
echo "<th>Sno</th><th>Name</th><th>Author</th><th>Subject</th><th>BookId</th>";
echo"</tr>";
for($i=1;$i<=$row;$i++)
{
$arr=mysqli_fetch_array($result);
echo"<tr>";
echo"<td>".$i."</td>"."<td>".$arr['Name']."</td><td>".$arr['Author']."</td><td>".$arr['Subject']."</td><td>".$arr['Id']."</td><td><button>View</button><button>Issue</button>";
echo"</tr>";
}
echo"</table>";
}
?>
</body>       