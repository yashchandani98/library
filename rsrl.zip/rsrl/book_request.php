<style>
* {
  box-sizing: border-box;
}

#myInput {
  background-image: url('searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myTable {
  border-collapse: collapse;
  width: 100%;
  border: 1px solid #ddd;
  font-size: 18px;
}

#myTable th, #myTable td {
  text-align: left;
  padding: 12px;
}

#myTable tr {
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}

</style>
<script>
function myFunction() {
var input, filter, table, tr, td, i;
input = document.getElementById("myInput");
filter = input.value.toUpperCase();
table = document.getElementById("myTable");
tr = table.getElementsByTagName("tr");
for (i = 0; i < tr.length; i++) {
td = tr[i].getElementsByTagName("td")[0];
if (td) {
if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
tr[i].style.display = "";
} 
else {
tr[i].style.display = "none";
}
}       
}
}
</script>

<?php
$con=mysqli_connect('localhost','id3093682_yashchandani98','110198');
if(isset($con))
{
echo"<input type='text' id='myInput' onkeyup='myFunction()' placeholder='Enter rollno...' title='Search for requests'>";
mysqli_select_db($con,'id3093682_library');
$q1="SELECT * FROM bookrequest";
$result=mysqli_query($con,$q1);
$rows=mysqli_num_rows($result);
echo"<table id='myTable'>";
echo"<tr class='header'>";
echo"<th style='width:;'>RollNo</th>";
echo"<th style='width:;'>Name</th>";
echo"<th style='width:;'>BookName</th>";
echo"<th style='width:;'>BookId</th>";
echo"<th style='width:;'>Rack</th>";
echo"<th style='width:;'>RequestDate</th>";
echo"<th>Action</th>";
echo"</tr>";
$today=date("Y-m-d");
for($i=0;$i<$rows;$i++)
{
$arr=mysqli_fetch_array($result);
echo"<tr>";
echo"<td>".$arr['RollNo']."</td>";
echo"<td>".$arr['Name']."</td>";
echo"<td>".$arr['BookName']."</td>";
echo"<td>".$arr['BookId']."</td>";
echo"<td>".$arr['Rack']."</td>";
echo"<td>".$arr['Date']."</td>";
echo"<td><a href='delete_request.php?roll=$arr[RollNo]&book=$arr[BookName]&id=$arr[BookId]'>Delete Request</a></td>";
echo"</tr>";
}
}
?>