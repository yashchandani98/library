<?php
$conn=mysqli_connect('localhost','id3093682_yashchandani98','110198');
if(isset($conn))
{
mysqli_select_db($conn,'id3093682_library');
$roll=$_REQUEST['roll'];
$fine=$_POST['fine'];
$q1="SELECT * FROM user WHERE Rollno='$roll'";
$result=mysqli_query($conn,$q1);
$arr=mysqli_fetch_array($result);
$prevFine=$arr['Totalfine'];
$totalFine=$prevFine+$fine;
echo$totalFine;
$q2="UPDATE user SET Totalfine='$totalFine' WHERE RollNo='3292215044'";
//$q2="UPDATE user SET Totalfine='6' WHERE RollNo='3292215044'";
$re=mysqli_query($conn,$q2);
}
?>