<?php
$t=10;
echo"<script>alert($t);</script>";
?>