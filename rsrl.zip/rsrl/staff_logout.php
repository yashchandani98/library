<?php
session_start();
unset($_COOKIE['staff']);
session_destroy();
echo"<script>location='index3.php';</script>";
?>