<?Php
$con=mysqli_connect('localhost','root');
if(isset($con))
{
mysqli_select_db($con,'library');
$q1="SELECT * FROM image";
$q2=mysqli_query($con,$q1);
$result=mysqli_fetch_array($q2);
echo$result['Name'];
setcookie('image',$result['Name']);
echo"<img src='images/$_COOKIE[image]' height='45' width='50'>";
}
?>
<!--img src="getImage.php">