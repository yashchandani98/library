<?Php
$con=mysqli_connect('localhost','id3093682_yashchandani98','110198');
mysqli_select_db($con,'id3093682_library');
$nm=$_POST['bookName'];
$ath=$_POST['bookAuthor'];
$ed=$_POST['bookEdition'];
$dataTime = date("d-m-y");
//$check = getimagesize($_FILES["image"]["tmp_name"]);
$image = $_FILES['bookImg']['tmp_name'];
$imgContent = addslashes(file_get_contents($image));
$dataTime = date("d-m-y");
$insert = $con->query("INSERT into bookTitle (Name,image,Author,Edition,Date) VALUES ('$nm','$imgContent','$ath','$ed','$dataTime')");
if($insert)
	echo"Record inserted successfully";
	
?>