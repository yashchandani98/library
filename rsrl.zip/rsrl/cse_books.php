<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  </head>
<?php
$servername = "localhost";
$username = "id3093682_yashchandani98";
$password = "110198";
$dbname = "id3093682_library";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM bookTitle";
$res = mysqli_query($conn,$sql);
/*echo "<table class = 'table'>";
echo"<tr>";
echo"<th>"; echo"Book ID"; echo"</th>";
echo"<th>"; echo"Book Author"; echo"</th>";
echo"<th>"; echo"Book Name"; echo"</th>";
echo"<th>"; echo"Edition"; echo"</th>";
echo"<th>"; echo"Image"; echo"</th>";
echo"<th>"; echo"RackNumber"; echo"</th>";
echo"<th>"; echo"Created"; echo"</th>";
echo"</tr>";*/
//echo"<div class='thumbnail'>";
while($row = mysqli_fetch_array($res))
{
//echo"<tr>";
//echo"<td>"; 
echo"<div class='thumbnail'>";
echo '<img src="data:image/jpeg;base64,'.base64_encode( $row['image'] ).'"/>';
echo"<div class='caption'><p style='font-size:30px;'>Name:".$row['Name']."<br>Author:".$row['Author']."<br>Edition:".$row['Edition']."</p></div>";
//setcookie('book',$row['Name']);
echo"<a href='book_issue.php?name=$row[Name]' style='font-size:30;'>Issue</a>";
//echo"</div>";
//echo"<td>"; 
//echo $row["Id"]; 
//echo"</td>";
//echo"<td>"; echo $row["Author"]; echo"</td>";
//echo"<td>"; echo $row["Name"]; echo"</td>";
//echo"<td>"; echo $row["Edition"]; echo"</td>";
//echo"<td>"; echo $row["RackNumber"]; echo"</td>"; 
//echo"<td>"; echo $row["created"]; echo"</td>";
//echo"</tr>";


//echo"</table>";
//mysqli_close($conn);
//<div class='thumbnail'>
//<img src='' class='img-responsive'>
//</div>
echo"</div>";
}
echo"</div>";

?>