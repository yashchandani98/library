<?php
session_start();
if(isset($_SESSION['staff']))
{
echo"<frameset rows='26%,*'noresize border='1'>";
echo"<frame src='staff_nav.php'>";
echo"<frameset cols='15%,*'>";
echo"<frame src='staff_side_nav.php'>";
echo"<frame src='staff_down.php'name='down'>";
echo"</frameset>";
echo"</frameset>";
}
else{
echo"<script>location='index.php';</script>";
}
?>