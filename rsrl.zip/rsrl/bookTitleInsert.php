<?php
echo"<form action='bookTitle.php' method='post' enctype='multipart/form-data'>";
echo"BookName:";
echo"<input type='text' placeholder='Enter book name...'name='bookName' required>";
echo"<br>";
echo"Author:";
echo"<input type='text' placeholder='Enter Author name...'name='bookAuthor' required>";
echo"<br>";
echo"Image:";
echo"<input type='file' name='bookImg' required>";
echo"<br>";
echo"Edition:";
echo"<input type='number' placeholder='Enter edition...' name='bookEdition'>";
echo"<input type='submit' name='sub' value='Submit'>";
echo"</form>";
?>